package org.upgrad.upstac.users.models;

public enum Gender {
    MALE,FEMALE,OTHER
}
